package tut10.adapter;

import tut10.adapter.adapter.SquarePegAdapter;
import tut10.adapter.round.RoundHole;
import tut10.adapter.round.RoundPeg;
import tut10.adapter.square.SquarePeg;

/**
 * Somewhere in client code...
 */
public class Demo {

    public static void main(String[] args) {
        //TO-DO: Create 2 instances of RoundHole and RoundPeg with same radius
        RoundHole hole = new RoundHole(6);
        RoundPeg rpeg = new RoundPeg(4);
        //TO-DO: If RoundHole instance can "fits" with RoundPeg instance => show a message
        if (hole.fits(rpeg)) {
            System.out.println("Round Peg R4 can fit Round Hole R6");
        }
        //TO-DO: Create 2 instances of SquarePeg with 2 different widths
        SquarePeg smallPeg = new SquarePeg(2);
        SquarePeg largePeg = new SquarePeg(20);
        //Note: You can't make RoundHole instance "fit" with SquarePeg instance
        //Therefore, we need to use Adapter for solving the problem.
        //TO-DO: Create 2 corresponding instances of SquarePegAdapter
        SquarePegAdapter smallPegAdapter = new SquarePegAdapter(smallPeg);
        SquarePegAdapter largePegAdapter = new SquarePegAdapter(largePeg);
        //TO-DO: If the RoundHole instance can "fits" with "small" RoundPegAdapter instance 
        //show a suitable message
        if (hole.fits(smallPegAdapter)) {
            System.out.println("Square Peg w2 can fit Round Hole R6");
        }
        //TO-DO: If the RoundHole instance can not "fits" with "big" RoundPegAdapter instance 
        //show a suitable message
        if (!hole.fits(largePegAdapter)) {
            System.out.println("Square Peg w20 cannot fit Round Hole R6");
        }
    }
}
