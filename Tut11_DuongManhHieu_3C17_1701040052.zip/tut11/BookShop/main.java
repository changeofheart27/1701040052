package tut11.BookShop;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class main {
    public static void main(String[] args) {
        Book b1 = new Book("Harry Potter", "JK Rowling", 20.0);
        System.out.println(b1.toString());
        GoldenEditionBook gb1 = new GoldenEditionBook("Lord of the Rings", "Tolkien", 30.0);
        System.out.println(gb1.toString());
    }
}
