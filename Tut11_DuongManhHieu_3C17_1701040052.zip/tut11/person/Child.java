package tut11.person;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class Child extends Person {
    private int height;
    
    public Child(int age, String name, int height) {
        super(age, name);
        this.height = height;
    }
    
    public int getHeight() {
        return height;
    }
    
    public void setHeight() {
        this.height = height;
    }
    
    @Override
    public void setAge(int age) throws IllegalArgumentException {
        if (age > 15) {
            throw new IllegalArgumentException("Child's age must be lesser than 15!");
        } else {
            super.setAge(age);
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(String.format("Name: %s, Age: %d, Height: %d", super.getName(), super.getAge(), this.height));
        return sb.toString();
    }
    
}
