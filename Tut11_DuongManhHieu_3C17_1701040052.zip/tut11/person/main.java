package tut11.person;

import java.util.Scanner;
/**
 *
 * @author CHANGE.OF.HEART
 */
public class main {
    public static void main(String[] args) {
        Person p1 = new Person(21, "Hiếu");
        System.out.println(p1.toString());
        Child c1 = new Child(10, "Dương", 130);
        System.out.println(c1.toString());
        
    }
}
