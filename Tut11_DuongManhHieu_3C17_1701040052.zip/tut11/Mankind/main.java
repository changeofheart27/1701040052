package tut11.Mankind;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class main {
    public static void main(String[] args) {
        Student s1 = new Student("Hiếu", "Dương", 1701040052);
        System.out.println(s1.toString());
        Worker w1 = new Worker("Hiếu", "Dương", 500000.0, 8);
        System.out.println(w1.toString());
    }
}
