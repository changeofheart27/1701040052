package tut11.Mankind;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class Human {
    private String firstName;
    protected String lastName;
    
    public Human(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) throws IllegalArgumentException {
        char first = firstName.charAt(0);
        if (!Character.isUpperCase(first)) {
            throw new IllegalArgumentException("Expected upper case letter! Argument: " + firstName);
        } else if(firstName.length() < 4) {
            throw new IllegalArgumentException("Expected length at least 4 symbols! Argument: " + firstName);
        }
        else {
            this.firstName = firstName;
        }
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) throws IllegalArgumentException {
        char first = lastName.charAt(0);
        if (!Character.isUpperCase(first)) {
            throw new IllegalArgumentException("Expected upper case letter! Argument: " + lastName);
        } else {
            this.lastName = lastName;
        }
    }
}
