package jersey.Service;

import jersey.model.Customer;
import java.util.List;
import java.util.ArrayList;

public class CustomerService {
	public List<Customer> displayCustomers() {
		Customer c1 = new Customer(1, "laptop", 2);
		Customer c2 = new Customer(2, "monitor", 5);
		List<Customer> customerList = new ArrayList<Customer>();
		customerList.add(c1);
		customerList.add(c2);
		return customerList;
	}
}
