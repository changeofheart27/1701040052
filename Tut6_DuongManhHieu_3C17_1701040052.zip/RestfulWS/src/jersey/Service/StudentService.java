package jersey.Service;

import jersey.model.Student;
import java.util.List;
import java.util.ArrayList;

public class StudentService {
	public List<Student> displayStudent() {
		Student s1 = new Student(1701040052, "Hieu Duong", "SE2");
		Student s2 = new Student(250040174, "Duong Hieu", "SQA");
		List<Student> listStudent = new ArrayList<Student>();
		listStudent.add(s1);
		listStudent.add(s2);
		return listStudent;
	}
}
