package jersey.Service;

import jersey.model.User;
import java.util.List;
import java.util.ArrayList;

public class UserService {
	public List<User> displayUser() {
		User u1 = new User(1, "Manh Hieu", "0912345678");
		User u2 = new User(2, "Hieu Lul", "0987654321");
		List<User> list = new ArrayList<User>();
		list.add(u1);
		list.add(u2);
		return list;
	}
}
