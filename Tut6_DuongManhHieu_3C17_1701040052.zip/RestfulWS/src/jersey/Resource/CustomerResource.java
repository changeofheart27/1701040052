package jersey.Resource;

import jersey.model.Customer;
import jersey.Service.CustomerService;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/customerlist")
public class CustomerResource {
	CustomerService customerService = new CustomerService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Customer> showCustomer() {
		return customerService.displayCustomers();
	}
}
