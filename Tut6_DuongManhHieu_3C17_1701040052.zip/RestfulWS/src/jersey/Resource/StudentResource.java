package jersey.Resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.Service.StudentService;
import jersey.model.Student;
import java.util.List;

@Path("/studentlist")
public class StudentResource {
	StudentService studentService = new StudentService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Student> showStudent() {
		return studentService.displayStudent();
	}
}
