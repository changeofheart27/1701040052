package jersey.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Customer {
	private int customerID;
	private String order;
	private int quantity;
	
	public Customer() {
		super();
	}
	public Customer(int customerID, String order, int quantity) {
		super();
		this.customerID = customerID;
		this.order = order;
		this.quantity = quantity;
	}
	
	public int getCustomerID() {
		return customerID;
	}
	
	public String getOrder() {
		return order;
	}
	
	public void setOrder(String order) {
		this.order = order;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
