package jersey.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class User {
	private int userID;
	private String name;
	private String mobile;
	
	public User() {
		super();
	}
	
	public User(int userID, String name, String mobile) {
		super();
		this.userID = userID;
		this.name = name;
		this.mobile = mobile;
	}

	public int getUserID() {
		return userID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getMobile() {
		return mobile;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
}
