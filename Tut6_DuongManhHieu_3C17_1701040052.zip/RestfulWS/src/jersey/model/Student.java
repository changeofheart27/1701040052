package jersey.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Student {
	private int userID;
	private String name;
	private String subject;
	
	public Student() {
		super();
	}
	
	public Student(int userID, String name, String subject) {
		super();
		this.userID = userID;
		this.name = name;
		this.subject = subject;
	}

	public int getUserID() {
		return userID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	
	
	
}
