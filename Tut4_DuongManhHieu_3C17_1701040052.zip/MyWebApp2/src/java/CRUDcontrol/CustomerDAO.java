package CRUDcontrol;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import DBconnection.connect;
import model.Customer;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class CustomerDAO {
    public CustomerDAO() {
    }

    public static List<Customer> selectAllTeachers() {
        List<Customer> customers = new ArrayList<>();

        Connection connection = connect.getConnection();
        try {
            String SELECT_ALL_CUSTOMERS = "select * from Customer";
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_CUSTOMERS);
            ResultSet result = stm.executeQuery();
            while (result.next()) {
                int id = result.getInt("id");
                String name = result.getString("name");
                String item = result.getString("item");
                int quantity = result.getInt("quantity");
                customers.add(new Customer(id, name, item, quantity));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return customers;
    }
    
}
