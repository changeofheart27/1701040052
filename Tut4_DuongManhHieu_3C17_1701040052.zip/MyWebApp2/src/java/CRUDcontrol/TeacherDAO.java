package CRUDcontrol;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import DBconnection.connect;
import model.Teacher;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class TeacherDAO {
    public TeacherDAO() {
    }
    
    public static List<Teacher> selectAllTeachers() {
        List<Teacher> students = new ArrayList<>();
        
        //Step 1: Establishing a Connection
        Connection connection = connect.getConnection();
        try {
            //Step 2: Create a statement using connection object
            String SELECT_ALL_TEACHERS = "select * from Teacher";
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_TEACHERS);
        
            //Step 3: Execute the query or update query
            ResultSet result = stm.executeQuery();
            
            //Step 4: Process the ResultSet object
            while (result.next()) {
                int id = result.getInt("id");
                String name = result.getString("name");
                String subject = result.getString("subject");
                String mobile = result.getString("mobile");
                students.add(new Teacher(id, name, subject, mobile));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return students;
    } 
}
