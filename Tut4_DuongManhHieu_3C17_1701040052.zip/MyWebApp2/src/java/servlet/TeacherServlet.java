package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

import java.util.List;
import CRUDcontrol.TeacherDAO;
import model.Teacher;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class TeacherServlet extends HttpServlet {
    private static final long serialversionUID = 1L;
    private TeacherDAO teacherDAO;
    
    @Override
    public void init() {
        teacherDAO = new TeacherDAO();
    }
    
    private void listTeacher(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Teacher> listTeacher = teacherDAO.selectAllTeachers();
        request.setAttribute("listTeacher", listTeacher);
        RequestDispatcher dispatcher = request.getRequestDispatcher("teacher-list.jsp");
        dispatcher.forward(request, response);
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        listTeacher(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
