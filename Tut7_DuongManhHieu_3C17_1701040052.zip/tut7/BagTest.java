package tut7;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class BagTest {
    public static void main(String[] args) {
        BagInterface<String> defaultBag = new ArrayBag<>();
        System.out.println("Current size: " + defaultBag.getCurrentSize());
        System.out.println("Bag is empty: " + defaultBag.isEmpty());
        
        defaultBag.add("HELLO");
        defaultBag.add("WORLD");
        defaultBag.add("HI");
        defaultBag.add("HIEU");
        System.out.println("Current size: " + defaultBag.getCurrentSize());
        System.out.println("Bag is empty: " + defaultBag.isEmpty());
        
        System.out.println("Remove object HIEU: " + defaultBag.remove("HIEU"));
        System.out.println("Current size: " + defaultBag.getCurrentSize());
        defaultBag.add("DUONG");
        System.out.println("Current size: " + defaultBag.getCurrentSize());
        System.out.println("Bag contains DUONG: " + defaultBag.contains("DUONG"));
        
        defaultBag.clear();
        System.out.println("Current size: " + defaultBag.getCurrentSize());
        
        BagInterface<String> customizedBag = new ArrayBag<>(50);
    }
}
