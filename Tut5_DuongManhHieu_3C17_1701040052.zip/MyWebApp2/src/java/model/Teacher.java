package model;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class Teacher {
    protected int id;
    protected String name;
    protected String subject;
    protected String mobile;

    public Teacher() {
    }

    public Teacher(String name, String subject, String mobile) {
        super();
        this.name = name;
        this.subject = subject;
        this.mobile = mobile;
    }

    public Teacher(int id, String name, String subject, String mobile) {
        super();
        this.id = id;
        this.name = name;
        this.subject = subject;
        this.mobile = mobile;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
}
