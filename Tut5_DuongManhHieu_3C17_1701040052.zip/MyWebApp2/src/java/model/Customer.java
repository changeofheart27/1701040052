package model;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class Customer {
    protected int id;
    protected String name;
    protected String item;
    protected int quantity;

    public Customer() {
    }

    public Customer(String name, String item, int quantity) {
        super();
        this.name = name;
        this.item = item;
        this.quantity = quantity;
    }

    public Customer(int id, String name, String item, int quantity) {
        super();
        this.id = id;
        this.name = name;
        this.item = item;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
}
