/**
 * Author:  CHANGE.OF.HEART
 * Created: Apr 17, 2020
 */
create table Student (
id int auto_increment primary key,
name varchar(30) not null,
address varchar(50) not null,
mobile varchar(10) not null
);
insert into Student (name, address, mobile) values
('Hieu', 'Ha Noi', '0912345678'), ('Duong', 'Ha Tay', '0123456789'), ('Manh', 'Ha Dong', '0912345687');
select * from Student;

create table Teacher (
id int auto_increment primary key,
name varchar(30) not null,
subject varchar(50) not null,
mobile varchar(10) not null
);
insert into Teacher (name, subject, mobile) values
('Cam', 'Database Structure', '0912345678'), ('Duc', 'Software Engineering 1', '0123456789'), ('Huong', 'Statistics', '0912345687');
select * from Teacher;

create table Customer (
id int auto_increment primary key,
name varchar(30) not null,
item varchar(50) not null,
quantity int not null
);
insert into Customer (name, item, quantity) values
('Hai', 'USB', 1), ('Khoa', 'Laptop', 1), ('Son', 'Steam game', 5);
select * from Customer;
