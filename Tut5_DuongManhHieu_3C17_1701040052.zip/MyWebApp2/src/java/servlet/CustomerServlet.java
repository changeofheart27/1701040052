package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.sql.SQLException;

import java.util.List;
import CRUDcontrol.CustomerDAO;
import model.Customer;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class CustomerServlet extends HttpServlet {
    private static final long serialversionUID = 1L;
    private CustomerDAO customerDAO;
    
    @Override
    public void init() {
        customerDAO = new CustomerDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        try {
            switch (action) {
                case "/newCustomer":
                    showNewForm(request, response);
                    break;
                case "/editCustomer":
                    showEditForm(request, response);
                    break;
                case "/insertCustomer":
                    insertCustomer(request, response);
                    break;
                case "/updateCustomer":
                    updateCustomer(request, response);
                    break;
                case "/deleteCustomer":
                    deleteCustomer(request, response);
                    break;
                default:
                    listCustomer(request, response);
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    
    private void listCustomer(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException   {
        List<Customer> listCustomer = customerDAO.selectAllCustomers();
        request.setAttribute("listCustomer", listCustomer);
        RequestDispatcher dispatcher = request.getRequestDispatcher("customer-list.jsp");
        dispatcher.forward(request, response);
    }
    
    //insertCustomer() method for adding new Customer
    private void insertCustomer(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String item = request.getParameter("item");
        int quantity = request.getIntHeader("quantity");
        Customer newCustomer = new Customer(name, item, quantity);
        customerDAO.insertCustomer(newCustomer);
        response.sendRedirect("Clist");
    }
    
    //updateCustomer() method for updating existing customer
    private void updateCustomer(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String item = request.getParameter("item");
        int quantity = request.getIntHeader("quantity");
        Customer updateCustomer = new Customer(id, name, item, quantity);
        customerDAO.updateCustomer(updateCustomer);
        response.sendRedirect("Clist");
    }
    
    //deleteCustomer() method for deleting existing customer
    private void deleteCustomer(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        customerDAO.deleteCustomer(id);
        response.sendRedirect("Clist");
    }
    
    //showNewForm() method which navigates to ADD CUSTOMER view (add-customer.jsp)
    private void showNewForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("add-customer.jsp");
        dispatcher.forward(request, response);
    }
    
    //showEditForm() method which navigates to EDIT CUSTOMER view (edit-customer.jsp)
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        Customer existingCustomer = customerDAO.selectCustomer(id);
        request.setAttribute("customer", existingCustomer);
        RequestDispatcher dispatcher = request.getRequestDispatcher("edit-customer.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
