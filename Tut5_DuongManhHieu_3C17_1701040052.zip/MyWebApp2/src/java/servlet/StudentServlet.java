package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.sql.SQLException;

import CRUDcontrol.StudentDAO;
import java.util.List;
import model.Student;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class StudentServlet extends HttpServlet {
    private static final long serialversionUID = 1L;
    private StudentDAO studentDAO;
    
    @Override
    public void init() {
        studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        try {
            switch (action) {
                case "/newStudent":
                    showNewForm(request, response);
                    break;
                case "/editStudent":
                    showEditForm(request, response);
                    break;
                case "/insertStudent":
                    insertStudent(request, response);
                    break;
                case "/updateStudent":
                    updateStudent(request, response);
                    break;
                case "/deleteStudent":
                    deleteStudent(request, response);
                    break;
                default:
                    listStudent(request, response);
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    
    private void listStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException   {
        List<Student> listStudent = studentDAO.selectAllStudents();
        request.setAttribute("listStudent", listStudent);
        RequestDispatcher dispatcher = request.getRequestDispatcher("student-list.jsp");
        dispatcher.forward(request, response);
    }
    
    //insertStudent() method for adding new student
    private void insertStudent(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String mobile = request.getParameter("mobile");
        Student newStudent = new Student(name, address, mobile);
        studentDAO.insertStudent(newStudent);  
        response.sendRedirect("Slist");
    }
    
    //updateStudent() method for updating existing student
    private void updateStudent(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String mobile = request.getParameter("mobile");
        Student updateStudent = new Student(id, name, address, mobile);
        studentDAO.updateStudent(updateStudent);
        response.sendRedirect("Slist");
    }
    
    //deleteStudent() method for deleting existing student
    private void deleteStudent(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        studentDAO.deleteStudent(id);
        response.sendRedirect("Slist");
    }
    
    //showNewForm() method which navigates to ADD STUDENT view (add-student.jsp)
    private void showNewForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("add-student.jsp");
        dispatcher.forward(request, response);
    }
    
    //showEditForm() method which navigates to EDIT STUDENT view (edit-student.jsp)
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        Student existingStudent = studentDAO.selectStudent(id);
        request.setAttribute("student", existingStudent);
        RequestDispatcher dispatcher = request.getRequestDispatcher("edit-student.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
}
