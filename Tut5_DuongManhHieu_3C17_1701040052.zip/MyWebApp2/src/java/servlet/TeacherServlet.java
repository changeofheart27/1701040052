package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

import java.util.List;
import CRUDcontrol.TeacherDAO;
import model.Teacher;
import java.sql.SQLException;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class TeacherServlet extends HttpServlet {
    private static final long serialversionUID = 1L;
    private TeacherDAO teacherDAO;
    
    @Override
    public void init() {
        teacherDAO = new TeacherDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        try {
            switch (action) {
                case "/newTeacher":
                    showNewForm(request, response);
                    break;
                case "/editTeacher":
                    showEditForm(request, response);
                    break;
                case "/insertTeacher":
                    insertTeacher(request, response);
                    break;
                case "/updateTeacher":
                    updateTeacher(request, response);
                    break;
                case "/deleteTeacher":
                    deleteTeacher(request, response);
                    break;
                default:
                    listTeacher(request, response);
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    
    private void listTeacher(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException   {
        List<Teacher> listTeacher = teacherDAO.selectAllTeachers();
        request.setAttribute("listTeacher", listTeacher);
        RequestDispatcher dispatcher = request.getRequestDispatcher("teacher-list.jsp");
        dispatcher.forward(request, response);
    }
    
    //insertTeacher() method for adding new Teacher
    private void insertTeacher(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String subject = request.getParameter("subject");
        String mobile = request.getParameter("mobile");
        Teacher newTeacher = new Teacher(name, subject, mobile);
        teacherDAO.insertTeacher(newTeacher);  
        response.sendRedirect("Teacher");
    }
    
    //updateTeacher() method for updating existing teacher
    private void updateTeacher(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String subject = request.getParameter("subject");
        String mobile = request.getParameter("mobile");
        Teacher updateTeacher = new Teacher(id, name, subject, mobile);
        teacherDAO.updateTeacher(updateTeacher);
        response.sendRedirect("Teacher");
    }
    
    //deleteTeacher() method for deleting existing teacher
    private void deleteTeacher(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        teacherDAO.deleteTeacher(id);
        response.sendRedirect("Teacher");
    }
    
    //showNewForm() method which navigates to ADD TEACHER view (add-teacher.jsp)
    private void showNewForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("add-teacher.jsp");
        dispatcher.forward(request, response);
    }
    
    //showEditForm() method which navigates to EDIT TEACHER view (edit-teacher.jsp)
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        Teacher existingTeacher = teacherDAO.selectTeacher(id);
        request.setAttribute("teacher", existingTeacher);
//        RequestDispatcher dispatcher = request.getRequestDispatcher("edit-teacher.jsp");
//        dispatcher.forward(request, response);
        response.sendRedirect("Teacher");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
