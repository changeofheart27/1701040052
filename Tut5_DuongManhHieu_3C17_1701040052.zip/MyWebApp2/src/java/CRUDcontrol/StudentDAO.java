package CRUDcontrol;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.sql.SQLException;

import DBconnection.connect;
import model.Student;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class StudentDAO {
    public StudentDAO() {
    }
    
    public List<Student> selectAllStudents() {
        List<Student> students = new ArrayList<>();        
        
        //Step 1: Establishing a Connection
        Connection connection = connect.getConnection();
        try {
            //Step 2: Create a statement using connection object
            String SELECT_ALL_STUDENTS = "select * from Student";
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_STUDENTS);
            
            //Step 3: Execute the query or update query
            ResultSet result = stm.executeQuery();
            
            //Step 4: Process the ResultSet object
            while (result.next()) {
                int id = result.getInt("id");
                String name = result.getString("name");
                String address = result.getString("address");
                String mobile = result.getString("mobile");
                students.add(new Student(id, name, address, mobile));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }
    
    //selectStudent() method to select particular Student by ID (use in UPDATE function)
    public Student selectStudent(int id) {
        Student student = null;
        
        Connection connection = connect.getConnection();
        try {
            
            String SELECT_STUDENT = "select * from Student where id = ?";
            PreparedStatement stm = connection.prepareStatement(SELECT_STUDENT);
            stm.setInt(1, id);
            
            ResultSet result = stm.executeQuery();
            
            if (result.next()) {
                String name = result.getString("name");
                String address = result.getString("address");
                String mobile = result.getString("mobile");
                student = new Student(id, name, address, mobile);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
    }
    
    //insertStudent() method to add a new record to Student table
    public void insertStudent(Student student) throws SQLException {
        Connection connection = connect.getConnection();
        try {
            String INSERT_STUDENT = "insert into Student (name, address, mobile) values (?, ?, ?)";
            PreparedStatement stm = connection.prepareStatement(INSERT_STUDENT);
            stm.setString(1, student.getName());
            stm.setString(2, student.getAddress());
            stm.setString(3, student.getMobile());

            stm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //updateStudent() method to update record to table Student
    public boolean updateStudent(Student student) throws SQLException {
        Connection connection = connect.getConnection();
        boolean rowUpdated = false;
        try {
            String UPDATE_STUDENT = "update Student set name = ?, address = ?, mobile = ? where id = ?";
            PreparedStatement stm = connection.prepareStatement(UPDATE_STUDENT);
            stm.setString(1, student.getName());
            stm.setString(2, student.getAddress());
            stm.setString(3, student.getMobile());
            stm.setInt(4, student.getId());
            
            rowUpdated = stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }
    
    //deleteStudent() method to delete record to table Student
    public boolean deleteStudent(int id) throws SQLException {
        Connection connection = connect.getConnection();
        boolean rowDeleted = false;
        try {
            String DELETE_STUDENT = "delete from Student where id = ?";
            PreparedStatement stm = connection.prepareStatement(DELETE_STUDENT);
            stm.setInt(1, id);
            
            rowDeleted = stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }
}
