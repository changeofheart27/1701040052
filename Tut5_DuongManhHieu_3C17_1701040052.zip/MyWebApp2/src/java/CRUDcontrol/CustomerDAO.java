package CRUDcontrol;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;
import java.sql.SQLException;

import DBconnection.connect;
import model.Customer;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class CustomerDAO {
    public CustomerDAO() {
    }

    public List<Customer> selectAllCustomers() {
        List<Customer> customers = new ArrayList<>();

        Connection connection = connect.getConnection();
        try {
            String SELECT_ALL_CUSTOMERS = "select * from Customer";
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_CUSTOMERS);
            ResultSet result = stm.executeQuery();
            while (result.next()) {
                int id = result.getInt("id");
                String name = result.getString("name");
                String item = result.getString("item");
                int quantity = result.getInt("quantity");
                customers.add(new Customer(id, name, item, quantity));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }
    
    //selectCustomer() method to select particular Customer by ID (use in UPDATE function)
    public Customer selectCustomer(int id) {
        Customer customer = null;
        
        Connection connection = connect.getConnection();
        try {
            
            String SELECT_CUSTOMER = "select * from Customer where id = ?";
            PreparedStatement stm = connection.prepareStatement(SELECT_CUSTOMER);
            stm.setInt(1, id);
            
            ResultSet result = stm.executeQuery();
            
            if (result.next()) {
                String name = result.getString("name");
                String item = result.getString("item");
                int quantity = result.getInt("quantity");
                customer = new Customer(id, name, item, quantity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }
    
    //insertCustomer() method to add a new record to Customer table
    public void insertCustomer(Customer customer) throws SQLException {
        Connection connection = connect.getConnection();
        try {
            String INSERT_CUSTOMER = "insert into Customer (name, item, quantity) values (?, ?, ?)";
            PreparedStatement stm = connection.prepareStatement(INSERT_CUSTOMER);
            stm.setString(1, customer.getName());
            stm.setString(2, customer.getItem());
            stm.setInt(3, customer.getQuantity());

            stm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //updateCustomer() method to update record to table Customer
    public boolean updateCustomer(Customer customer) throws SQLException {
        Connection connection = connect.getConnection();
        boolean rowUpdated = false;
        try {
            String UPDATE_CUSTOMER = "update Customer set name = ?, item = ?, quantity = ? where id = ?";
            PreparedStatement stm = connection.prepareStatement(UPDATE_CUSTOMER);
            stm.setString(1, customer.getName());
            stm.setString(2, customer.getItem());
            stm.setInt(3, customer.getQuantity());
            stm.setInt(4, customer.getId());
            
            rowUpdated = stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }
    
    //deleteCustomer() method to delete record to table Customer
    public boolean deleteCustomer(int id) throws SQLException {
        Connection connection = connect.getConnection();
        boolean rowDeleted = false;
        try {
            String DELETE_CUSTOMER = "delete from Customer where id = ?";
            PreparedStatement stm = connection.prepareStatement(DELETE_CUSTOMER);
            stm.setInt(1, id);
            
            rowDeleted = stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }
    
}
