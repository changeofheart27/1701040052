package CRUDcontrol;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;
import java.sql.SQLException;

import DBconnection.connect;
import model.Teacher;

/**
 *
 * @author CHANGE.OF.HEART
 */
public class TeacherDAO {
    public TeacherDAO() {
    }
    
    public List<Teacher> selectAllTeachers() {
        List<Teacher> students = new ArrayList<>();
        
        //Step 1: Establishing a Connection
        Connection connection = connect.getConnection();
        try {
            //Step 2: Create a statement using connection object
            String SELECT_ALL_TEACHERS = "select * from Teacher";
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_TEACHERS);
        
            //Step 3: Execute the query or update query
            ResultSet result = stm.executeQuery();
            
            //Step 4: Process the ResultSet object
            while (result.next()) {
                int id = result.getInt("id");
                String name = result.getString("name");
                String subject = result.getString("subject");
                String mobile = result.getString("mobile");
                students.add(new Teacher(id, name, subject, mobile));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }
    
    //selectTeacher() method to select particular Teacher by ID (use in UPDATE function)
    public Teacher selectTeacher(int id) {
        Teacher teacher = null;
        
        Connection connection = connect.getConnection();
        try {
            
            String SELECT_TEACHER = "select * from Teacher where id = ?";
            PreparedStatement stm = connection.prepareStatement(SELECT_TEACHER);
            stm.setInt(1, id);
            
            ResultSet result = stm.executeQuery();
            
            if (result.next()) {
                String name = result.getString("name");
                String subject = result.getString("subject");
                String mobile = result.getString("mobile");
                teacher = new Teacher(id, name, subject, mobile);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teacher;
    }
    
    //insertTeacher() method to add a new record to Teacher table
    public void insertTeacher(Teacher teacher) throws SQLException {
        Connection connection = connect.getConnection();
        try {
            String INSERT_TEACHER = "insert into Teacher (name, subject, mobile) values (?, ?, ?)";
            PreparedStatement stm = connection.prepareStatement(INSERT_TEACHER);
            stm.setString(1, teacher.getName());
            stm.setString(2, teacher.getSubject());
            stm.setString(3, teacher.getMobile());

            stm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //updateTeacher() method to update record to table Teacher
    public boolean updateTeacher(Teacher teacher) throws SQLException {
        Connection connection = connect.getConnection();
        boolean rowUpdated = false;
        try {
            String UPDATE_TEACHER = "update Teacher set name = ?, subject = ?, mobile = ? where id = ?";
            PreparedStatement stm = connection.prepareStatement(UPDATE_TEACHER);
            stm.setString(1, teacher.getName());
            stm.setString(2, teacher.getSubject());
            stm.setString(3, teacher.getMobile());
            stm.setInt(4, teacher.getId());
            
            rowUpdated = stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }
    
    //deleteTeacher() method to delete record to table Teacher
    public boolean deleteTeacher(int id) throws SQLException {
        Connection connection = connect.getConnection();
        boolean rowDeleted = false;
        try {
            String DELETE_TEACHER = "delete from Teacher where id = ?";
            PreparedStatement stm = connection.prepareStatement(DELETE_TEACHER);
            stm.setInt(1, id);
            
            rowDeleted = stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }
}
